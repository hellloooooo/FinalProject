import json
from data import data_

def convertToJSON():
    with open("r" 'E:\python\Lab 12', 'w') as write_file:
        json.dump(data_, write_file)
